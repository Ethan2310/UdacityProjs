package WorkingWithClasses;

public class PersonTester {

    public static void main(String[] args )
    {

        Person Bob = new Person("Bob","Phillips");
        Person Mike = new Person("Mike","Lipson");

        System.out.println(Bob);
        System.out.println(Mike);
    }
}
