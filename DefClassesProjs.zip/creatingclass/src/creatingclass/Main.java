package creatingclass;

import creatingclass.Dog;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        Dog myDog = new Dog("Huskey","Titan","Black and Brown",5);
        System.out.println(myDog.toString());




    }
}